#!/usr/bin/bash
#SBATCH --job-name=star-aln2
#SBATCH --time=01:00:00
#SBATCH --cpus-per-task=8
#SBATCH --mem=30G
#SBATCH -o star-aln-2pass.%a.o
#SBATCH -e star-aln-2pass.%a.e
#SBATCH --array 1-1%1


outDIR=STAR_Ruhland2016

mkdir -p $outDIR

dataDIR=/shared/data/DATA/Ruhland2016

sourceFILE=Ruhland2016.fastqFiles.txt

fastqFILE=`sed -n ${SLURM_ARRAY_TASK_ID}p $sourceFILE`


genomeDIR=/shared/data/DATA/Mouse_STAR_index

$singularity_exec STAR --runThreadN 8 --genomeDir $genomeDIR \
                  --outSAMtype BAM SortedByCoordinate \
                  --outFileNamePrefix $outDIR/$fastqFILE.2Pass. \
                  --outReadsUnmapped Fastx --quantMode GeneCounts \
                  --sjdbFileChrStartEnd $outDIR/${fastqFILE}SJ.out.tab \
                  --readFilesIn $dataDIR/$fastqFILE --readFilesCommand zcat \
		  --outTmpDir /tmp/${SLURM_JOB_USER}_${SLURM_JOB_ID}

