#!/usr/bin/bash
#SBATCH --job-name=fastqc
#SBATCH --time=00:30:00
#SBATCH --cpus-per-task=1
#SBATCH --mem=1G
#SBATCH -o fastqc_Ruhland2016.o

ml fastqc

mkdir -p 010_fastqc/

fastqc -o 010_fastqc /shared/data/DATA/Ruhland2016/*.fastq.gz

