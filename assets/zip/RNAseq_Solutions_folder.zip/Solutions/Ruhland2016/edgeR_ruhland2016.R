library(edgeR)

setwd("/shared/home/user01/Ruhland2016/")

# listing the counts files

countsFiles <- list.files(path="/shared/home/SHARED/Solutions/Ruhland2016/countFiles", pattern=".counts$", full.names=TRUE)
countsFiles

# reading the counts files

geneIDs <- read.table(countsFiles[1], header=FALSE, sep="\t")[,1]
raw_counts <- do.call(cbind, lapply(countsFiles, function(fn) read.table(fn, header=FALSE, sep="\t")[,2]))
rownames(raw_counts) <- geneIDs
colnames(raw_counts) <- gsub("/shared/home/SHARED/Solutions/Ruhland2016/countFiles/","",countsFiles)

raw_counts <- head(raw_counts, -5)	# remove last 5 rows (can you guess why?)

# some checking of what we just read
head(raw_counts); tail(raw_counts); dim(raw_counts)
colSums(raw_counts)

# creating the edgeR DGE object
dge.all <- DGEList(counts = raw_counts)  # filter by low counts?
dge.all <- calcNormFactors(dge.all)

# here is the filtering. Here we ask that CPM is at least 1 in at least 2 libraries
idx <- rowSums(cpm(dge.all) >= 1) >= 2
dge.f <- dge.all[idx, keep.lib.sizes=FALSE]

# setting up the model
treatment <- c(rep(0,3),rep(1,3))
dge.f.design <- model.matrix(~ treatment)

# estimate of the dispersion
dge.f <- estimateDisp(dge.f,dge.f.design)
plotBCV(dge.f)

# fitting a glm over our model in order to perform tests
dge.f.fit <- glmFit(dge.f, dge.f.design)
dge.f.lrt <- glmLRT(dge.f.fit)
dge.f.res <- dge.f.lrt$table

# there is another fitting method reliying on quasi likelihood, which is useful when the model is more complex (ie. more than 1 factor with 2 levels)
dge.f.QLfit <- glmQLFit(dge.f, dge.f.design)
dge.f.qlt <- glmQLFTest(dge.f.QLfit, coef=2)

# you can see the results relatively different. The order of genes changes a bit, and the p-values are more profoundly affected
topTags(dge.f.lrt)
topTags(dge.f.qlt)

# how to extract log CPM
logcpm <- cpm(dge.f, prior.count=2, log=TRUE)

