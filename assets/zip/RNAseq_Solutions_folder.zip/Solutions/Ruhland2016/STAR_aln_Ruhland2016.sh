#!/usr/bin/bash
#SBATCH --job-name=star-aln
#SBATCH --time=01:00:00
#SBATCH --cpus-per-task=4
#SBATCH --mem=6G
#SBATCH -o star-aln.%a.o
#SBATCH -e star-aln.%a.e
#SBATCH --array 1-1%1


ml star

outDIR=STAR_Ruhland2016

mkdir -p $outDIR

dataDIR=/shared/data/DATA/Ruhland2016

sourceFILE=Ruhland2016.fastqFiles.txt

fastqFILE=`sed -n ${SLURM_ARRAY_TASK_ID}p $sourceFILE`


genomeDIR=/shared/data/DATA/Mouse_STAR_index

$singularity_exec STAR --runThreadN 4 --genomeDir $genomeDIR \
                  --outSAMtype BAM SortedByCoordinate --outReadsUnmapped Fastx \
                  --outFileNamePrefix $outDIR/$fastqFILE \
                  --quantMode GeneCounts \
                  --readFilesIn $dataDIR/$fastqFILE --readFilesCommand zcat \
		  --outTmpDir /tmp/${SLURM_JOB_USER}_${SLURM_JOB_ID}


