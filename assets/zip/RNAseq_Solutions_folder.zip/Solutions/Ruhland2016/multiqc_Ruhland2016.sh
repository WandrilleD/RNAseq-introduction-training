#!/usr/bin/bash
#SBATCH --job-name=multiqc
#SBATCH --time=00:30:00
#SBATCH --cpus-per-task=1
#SBATCH --mem=1G
#SBATCH -o multiqc_Ruhland2016.o
#SBATCH -e multiqc_Ruhland2016.e


mkdir -p MULTIQC_Ruhland2016/

~/.local/bin/multiqc -o MULTIQC_Ruhland2016/ FASTQC_Ruhland2016/ 

