# setup

library(DESeq2)

rm(list=ls())

setwd("/shared/home/user01/Ruhland2016/")

# listing the counts files

countsFiles <- list.files(path="/shared/home/SHARED/Solutions/Ruhland2016/countFiles", pattern=".counts$", full.names=TRUE)
countsFiles

# reading the counts files

geneIDs <- read.table(countsFiles[1], header=FALSE, sep="\t")[,1]
raw_counts <- do.call(cbind, lapply(countsFiles, function(fn) read.table(fn, header=FALSE, sep="\t")[,2]))
rownames(raw_counts) <- geneIDs
colnames(raw_counts) <- gsub("/shared/home/SHARED/Solutions/Ruhland2016/countFiles/","",countsFiles)

raw_counts <- head(raw_counts, -5)	# remove last 5 rows (can you guess why?)

# some checking of what we just read
head(raw_counts); tail(raw_counts); dim(raw_counts)
colSums(raw_counts)

# setting up the model
treatment <- c(rep("EtOH",3), rep("TAM",3))
colData <- data.frame(treatment, row.names = colnames(raw_counts))
colData

# creating the DESeq data object
dds <- DESeqDataSetFromMatrix(countData = raw_counts, colData = colData, design = ~ treatment)
dim(dds)

## filter low count genes . Here the filter is to have at least 2 samples where there is a least 5 reads
idx <- rowSums(counts(dds, normalized=FALSE) >= 5) >= 2
dds.f <- dds[idx, ]
dim(dds.f)

# we go from 46078 to 18010 genes

# we perform the estimation of dispersions 
dds.f <- DESeq(dds.f)

# we plot the estimate of the dispersions
# * black dot : raw
# * red dot : local trend
# * blue : corrected
plotDispEsts(dds.f)

# extracting results for the treatment versus control contrast
res <- results(dds.f)

head(coef(dds.f))
res.lfc <- lfcShrink(dds.f, coef=2, res=res) # adds estimate of the LFC the results table

#plotting to see the difference.  
par(mfrow=c(2,1))
DESeq2::plotMA(res)
DESeq2::plotMA(res.lfc)
# -> with shrinkage on the significativeness and logFC are more consistent
par()


hist(res$pvalue[res$baseMean > 1], breaks = 0:20/20, col = "grey50", 	border = "white")
hist(res.lfc$pvalue[res$baseMean > 1], breaks = 0:20/20, col = "grey50", 	border = "white")
#the distribution of p-values is similar

par()

res <- res[!is.na(res$log2FoldChange) & !is.na(res$padj),] # filtering NA out
res.f1 <- res[abs(res$log2FoldChange) >= 0.67 & res$padj <= 0.01,] # log2 FC > 0.67 , pval < 0.01
res.f2 <- res[abs(res$log2FoldChange) >= 1 & res$padj <= 0.01,] # log2 FC > 1 , pval < 0.01
res.sig <- res[unique(rownames(res.f1), rownames(res.f2)),]


# we apply the variance stabilising transformation to make the read counts comparable across libraries
# (nb : this is not needed for DESeq DE analysis, but rather for the PCA on the data. This replace normal PCA scaling)
vst.dds.f <- vst(dds.f, blind = FALSE)
vst.dds.f.counts <- assay(vst.dds.f)

plotPCA(vst.dds.f, intgroup = c("treatment"))


library(pheatmap)
topVarGenes <- head(order(rowVars(vst.dds.f.counts), decreasing = TRUE), 20)
mat  <- vst.dds.f.counts[ topVarGenes, ] #scaled counts of the top genes
mat  <- mat - rowMeans(mat)  # centering
pheatmap(mat)


library(AnnotationHub)
library(AnnotationDbi)
library(clusterProfiler)
library(ReactomePA)

library(org.Mm.eg.db)


hub <- AnnotationHub()
query(hub, "org.Mm.eg.db")
Mouse <- hub[["AH75743"]]
genes_universe <- bitr(rownames(res), fromType = "ENSEMBL",
                       toType = c("ENTREZID", "SYMBOL"),
                       OrgDb = Mouse)

dim(genes_universe)
length(rownames(dds.f))

genes_DE <- bitr(rownames(res.sig), fromType = "ENSEMBL",
                 toType = c("ENTREZID", "SYMBOL"),
                 OrgDb = Mouse)
dim(genes_DE)
length(rownames(res.sig))

# GO "biological process (BP)" enrichment
ego_bp <- enrichGO(gene          = as.character(unique(genes_DE$ENTREZID)),
                   universe      = as.character(unique(genes_universe$ENTREZID)),
                   OrgDb         = org.Mm.eg.db,
                   ont           = "BP",
                   pAdjustMethod = "BH",
                   pvalueCutoff  = 0.01,
                   qvalueCutoff  = 0.05,
                   readable      = TRUE)
head(ego_bp)
dotplot(ego_bp, showCategory = 20)
dotplot(ego_bp, x = "p.adjust", showCategory = 20)


# Reactome pathways enrichment
reactome.enrich <- enrichPathway(gene=as.character(unique(genes_DE$ENTREZID)),
                                 organism = "mouse",
                                 pAdjustMethod = "BH",
                                 qvalueCutoff = 0.01,
                                 readable=T,
                                 universe = genes_universe$ENTREZID)

dotplot(reactome.enrich)
dotplot(reactome.enrich, x = "p.adjust")

