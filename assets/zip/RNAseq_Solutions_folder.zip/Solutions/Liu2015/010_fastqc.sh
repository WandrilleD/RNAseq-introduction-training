#!/usr/bin/bash
#SBATCH --job-name=fastqc
#SBATCH --time=01:00:00
#SBATCH --cpus-per-task=1
#SBATCH --mem=1G
#SBATCH -o fastqc_Liu2015.o

ml fastqc

# creating the output folder
mkdir -p 010_fastqc/

fastqc -o 010_fastqc /shared/data/DATA/Liu2015/*.fastq.gz
