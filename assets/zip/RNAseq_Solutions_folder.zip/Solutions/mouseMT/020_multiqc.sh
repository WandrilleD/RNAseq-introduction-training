#!/usr/bin/bash
#SBATCH --job-name=multiqc
#SBATCH --time=00:30:00
#SBATCH --cpus-per-task=1
#SBATCH --mem=1G
#SBATCH -o multiqc_mouseMT.o

multiqc -n 020_multiqc_mouseMT.html -f --title raw_fastq 010_fastqc/