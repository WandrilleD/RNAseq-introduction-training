#!/usr/bin/bash
#SBATCH --job-name=trim_mouseMT_array
#SBATCH --time=01:00:00
#SBATCH --cpus-per-task=1
#SBATCH --mem=1G
#SBATCH -o trim_mouseMT.%a.o
#SBATCH --array=1-8%8

ml  trimmomatic

## creating output folder, in case it does not exists
mkdir -p 030_trim

INPUT_FOLDER=/shared/data/DATA/mouseMT

## each job grab a specific line from sampleNames.txt
SAMPLE=`sed -n ${SLURM_ARRAY_TASK_ID}p sampleNames.txt`


java -jar $EBROOTTRIMMOMATIC/trimmomatic-0.39.jar SE -phred33 \
                                         $INPUT_FOLDER/${SAMPLE}.fastq \
                                         030_trim/${SAMPLE}.trimmed.fastq \
                                         ILLUMINACLIP:/shared/data/DATA/adapters/TruSeq3-PE.fa:2:30:10 \
                                         SLIDINGWINDOW:3:25 2> 030_trim/trim_out.${SAMPLE}.log

