#!/usr/bin/bash
#SBATCH --job-name=map-multiqc
#SBATCH --time=00:30:00
#SBATCH --cpus-per-task=1
#SBATCH --mem=1G
#SBATCH -o multiqc-map-trim.o

## fastQC on trimmed fastq files
fastqc 030_trim/*.fastq -o 030_trim


## multiqc on the fastQC reports AND the trimmomatic logs
multiqc -n 032_multiqc_mouseMT_trimmed.html -f --title trimmed_fastq 030_trim/
