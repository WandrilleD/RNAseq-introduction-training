#!/usr/bin/bash
#SBATCH --job-name=map-multiqc
#SBATCH --time=00:30:00
#SBATCH --cpus-per-task=1
#SBATCH --mem=1G
#SBATCH -o multiqc-map-raw.o

multiqc -n 043_multiqc_mouseMT_mapped_raw.html -f --title mapped_raw 042_STAR_map_raw/