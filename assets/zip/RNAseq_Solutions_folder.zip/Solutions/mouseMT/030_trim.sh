#!/usr/bin/bash
#SBATCH --job-name=trim_mouseMT
#SBATCH --time=01:00:00
#SBATCH --cpus-per-task=1
#SBATCH --mem=1G
#SBATCH -o trim_mouseMT.o

ml  trimmomatic

## creating output folder, in case it does not exists
mkdir -p 030_trim

## we store the input folder in a variable, 
## to access its value, we will write $INPUT_FOLDER
INPUT_FOLDER=/shared/data/DATA/mouseMT

## by ending a line with \ we can continue the same command on the line below

java -jar $EBROOTTRIMMOMATIC/trimmomatic-0.39.jar SE -phred33 \
                                         $INPUT_FOLDER/sample_a1.fastq \
                                         030_trim/sample_a1.trimmed.fastq \
                                         ILLUMINACLIP:/shared/data/DATA/adapters/TruSeq3-PE.fa:2:30:10 \
                                         SLIDINGWINDOW:3:25 2> 030_trim/trim_out.sample_a1.log

java -jar $EBROOTTRIMMOMATIC/trimmomatic-0.39.jar SE -phred33 \
                                         $INPUT_FOLDER/sample_a2.fastq \
                                         030_trim/sample_a2.trimmed.fastq \
                                         ILLUMINACLIP:/shared/data/DATA/adapters/TruSeq3-PE.fa:2:30:10 \
                                         SLIDINGWINDOW:3:25 2> 030_trim/trim_out.sample_a2.log

java -jar $EBROOTTRIMMOMATIC/trimmomatic-0.39.jar SE -phred33 \
                                         $INPUT_FOLDER/sample_a3.fastq \
                                         030_trim/sample_a3.trimmed.fastq \
                                         ILLUMINACLIP:/shared/data/DATA/adapters/TruSeq3-PE.fa:2:30:10 \
                                         SLIDINGWINDOW:3:25 2> 030_trim/trim_out.sample_a3.log

java -jar $EBROOTTRIMMOMATIC/trimmomatic-0.39.jar SE -phred33 \
                                         $INPUT_FOLDER/sample_a4.fastq \
                                         030_trim/sample_a4.trimmed.fastq \
                                         ILLUMINACLIP:/shared/data/DATA/adapters/TruSeq3-PE.fa:2:30:10 \
                                         SLIDINGWINDOW:3:25 2> 030_trim/trim_out.sample_a4.log


java -jar $EBROOTTRIMMOMATIC/trimmomatic-0.39.jar SE -phred33 \
                                         $INPUT_FOLDER/sample_b1.fastq \
                                         030_trim/sample_b1.trimmed.fastq \
                                         ILLUMINACLIP:/shared/data/DATA/adapters/TruSeq3-PE.fa:2:30:10 \
                                         SLIDINGWINDOW:3:25 2> 030_trim/trim_out.sample_b1.log

java -jar $EBROOTTRIMMOMATIC/trimmomatic-0.39.jar SE -phred33 \
                                         $INPUT_FOLDER/sample_b2.fastq \
                                         030_trim/sample_b2.trimmed.fastq \
                                         ILLUMINACLIP:/shared/data/DATA/adapters/TruSeq3-PE.fa:2:30:10 \
                                         SLIDINGWINDOW:3:25 2> 030_trim/trim_out.sample_b2.log

java -jar $EBROOTTRIMMOMATIC/trimmomatic-0.39.jar SE -phred33 \
                                         $INPUT_FOLDER/sample_b3.fastq \
                                         030_trim/sample_b3.trimmed.fastq \
                                         ILLUMINACLIP:/shared/data/DATA/adapters/TruSeq3-PE.fa:2:30:10 \
                                         SLIDINGWINDOW:3:25 2> 030_trim/trim_out.sample_b3.log

java -jar $EBROOTTRIMMOMATIC/trimmomatic-0.39.jar SE -phred33 \
                                         $INPUT_FOLDER/sample_b4.fastq \
                                         030_trim/sample_b4.trimmed.fastq \
                                         ILLUMINACLIP:/shared/data/DATA/adapters/TruSeq3-PE.fa:2:30:10 \
                                         SLIDINGWINDOW:3:25 2> 030_trim/trim_out.sample_b4.log

